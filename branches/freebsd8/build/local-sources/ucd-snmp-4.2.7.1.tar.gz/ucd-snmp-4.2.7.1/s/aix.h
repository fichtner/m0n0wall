#include "generic.h"
#include <sys/select.h>
#undef TOTAL_MEMORY_SYMBOL
