/* freebsd5 is a superset of freebsd4 */
#define   freebsd4 1
#include "freebsd4.h"
