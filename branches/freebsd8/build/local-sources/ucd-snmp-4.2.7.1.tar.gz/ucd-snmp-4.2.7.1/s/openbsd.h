#include "netbsd.h"

#define netbsd1 1 /* we're really close to this */
#define UVM

#undef MBPOOL_SYMBOL
#undef MCLPOOL_SYMBOL
#undef TOTAL_MEMORY_SYMBOL
