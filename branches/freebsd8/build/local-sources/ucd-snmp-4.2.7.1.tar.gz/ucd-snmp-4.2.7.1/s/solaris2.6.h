#include "solaris.h"
#define _SLASH_PROC_METHOD_ 1

#undef NPROC_SYMBOL
#undef TOTAL_MEMORY_SYMBOL
#undef MBSTAT_SYMBOL
#undef PHYSMEM_SYMBOL

